// category_chip.dart
import 'package:flutter/material.dart';

class CategoryChip extends StatelessWidget {
  final String category;

  const CategoryChip({Key? key, required this.category}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Color chipColor = _getChipColor(category);

    return Chip(
      label: Text(
        category,
        style: const TextStyle(color: Colors.white, fontSize: 12),
      ),
      backgroundColor: chipColor,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
    );
  }

  Color _getChipColor(String category) {
    switch (category.toLowerCase()) {
      case 'groceries':
        return Colors.green;
      case 'utilities':
        return Colors.blue;
      case 'electronics':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }
}
