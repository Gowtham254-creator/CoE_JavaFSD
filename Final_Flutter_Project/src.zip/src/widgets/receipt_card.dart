// 📄 receipt_card.dart
import 'package:flutter/material.dart';
import 'category_chip.dart';

class ReceiptCard extends StatelessWidget {
  final String store;
  final String totalAmount;
  final String category;

  const ReceiptCard({
    Key? key,
    required this.store,
    required this.totalAmount,
    required this.category,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        contentPadding: const EdgeInsets.all(12),
        title: Text(
          store,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        subtitle: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              totalAmount,
              style: const TextStyle(fontSize: 16, color: Colors.green),
            ),
            CategoryChip(category: category),
          ],
        ),
      ),
    );
  }
}
