import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web; // ✅ Web support
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  // ✅ Web Configuration
  static const FirebaseOptions web = FirebaseOptions(
    apiKey: "AIzaSyAinYuVXQaB5H1FWscSSE6tFg9-IoyBJhs",
    authDomain: "ocrproject-fdbfb.firebaseapp.com",
    projectId: "ocrproject-fdbfb",
    storageBucket: "ocrproject-fdbfb.appspot.com",
    messagingSenderId: "275827649248",
    appId: "1:275827649248:web:f7394e1aefa8c3d94d3e85",
    measurementId: "G-T0F4K4S73D",
  );

  // ✅ Android Configuration
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: "YOUR_ANDROID_API_KEY",
    appId: "YOUR_ANDROID_APP_ID",
    messagingSenderId: "YOUR_ANDROID_MESSAGING_SENDER_ID",
    projectId: "ocrproject-fdbfb",
    storageBucket: "ocrproject-fdbfb.appspot.com",
  );

  // ✅ iOS Configuration (if applicable)
  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: "YOUR_IOS_API_KEY",
    appId: "YOUR_IOS_APP_ID",
    messagingSenderId: "YOUR_IOS_MESSAGING_SENDER_ID",
    projectId: "ocrproject-fdbfb",
    storageBucket: "ocrproject-fdbfb.appspot.com",
    iosClientId: "YOUR_IOS_CLIENT_ID",
    iosBundleId: "YOUR_IOS_BUNDLE_ID",
  );
}
