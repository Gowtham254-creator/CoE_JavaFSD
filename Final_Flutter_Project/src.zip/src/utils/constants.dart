// constants.dart
class AppConstants {
  static const String receiptCollection = 'receipts';

  static const List<String> receiptCategories = [
    'Groceries',
    'Utilities',
    'Electronics',
    'Clothing',
    'Healthcare',
    'Others',
  ];
}
