import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';
import 'dart:typed_data';

class FirebaseService {
  final CollectionReference receiptsCollection =
      FirebaseFirestore.instance.collection('receipts');
  final FirebaseStorage _storage = FirebaseStorage.instance;

  // ✅ Add New Receipt to Firestore and Return ID
  Future<String?> addReceipt(Map<String, dynamic> receiptData) async {
    try {
      final receiptRef = await receiptsCollection.add(receiptData);
      print('✅ Receipt added successfully with ID: ${receiptRef.id}');
      return receiptRef.id; // Return document ID after adding
    } catch (e) {
      print('❌ Error adding receipt: $e');
      return null;
    }
  }

  // ✅ Upload Receipt Image to Firebase Storage
  Future<String?> uploadReceiptImage(
      File? imageFile, Uint8List? webImage) async {
    try {
      final ref =
          _storage.ref('receipts/${DateTime.now().millisecondsSinceEpoch}.jpg');

      if (imageFile != null) {
        // Upload for Mobile
        await ref.putFile(imageFile);
      } else if (webImage != null) {
        // Upload for Web
        await ref.putData(
            webImage, SettableMetadata(contentType: 'image/jpeg'));
      } else {
        print('⚠️ No image provided to upload.');
        return null;
      }

      final imageUrl = await ref.getDownloadURL();
      print('✅ Image uploaded successfully: $imageUrl');
      return imageUrl;
    } catch (e) {
      print('❌ Error uploading image: $e');
      return null;
    }
  }

  // ✅ Delete Receipt and Associated Image by ID
  Future<void> deleteReceipt(String receiptId) async {
    try {
      final receiptDoc = await receiptsCollection.doc(receiptId).get();

      if (receiptDoc.exists) {
        final receiptData = receiptDoc.data() as Map<String, dynamic>?;

        // ✅ Delete Image from Storage (if exists)
        if (receiptData != null && receiptData.containsKey('imageUrl')) {
          String? imageUrl = receiptData['imageUrl'];
          if (imageUrl != null && imageUrl.isNotEmpty) {
            await _deleteImageFromStorage(imageUrl);
          }
        }

        // ✅ Delete Receipt from Firestore
        await receiptsCollection.doc(receiptId).delete();
        print('✅ Receipt and associated image deleted successfully.');
      } else {
        print('⚠️ No receipt found with ID: $receiptId');
      }
    } catch (e) {
      print('❌ Error deleting receipt: $e');
    }
  }

  // ✅ Delete Image from Firebase Storage
  Future<void> _deleteImageFromStorage(String imageUrl) async {
    try {
      final ref = _storage.refFromURL(imageUrl);
      await ref.delete();
      print('✅ Image deleted from storage.');
    } catch (e) {
      print('⚠️ Error deleting image: $e');
    }
  }

  // ✅ Get Receipts Stream (Real-time Updates)
  Stream<QuerySnapshot> getReceipts() {
    try {
      return receiptsCollection.orderBy('date', descending: true).snapshots();
    } catch (e) {
      print('❌ Error fetching receipts stream: $e');
      return const Stream.empty(); // Return an empty stream on error
    }
  }

  // ✅ Get a Single Receipt by ID
  Future<DocumentSnapshot?> getReceiptById(String receiptId) async {
    try {
      final receiptDoc = await receiptsCollection.doc(receiptId).get();
      if (receiptDoc.exists) {
        print('✅ Receipt found: ${receiptDoc.data()}');
        return receiptDoc;
      } else {
        print('⚠️ No receipt found with ID: $receiptId');
        return null;
      }
    } catch (e) {
      print('❌ Error fetching receipt by ID: $e');
      return null;
    }
  }

  // ✅ Filter Receipts by Category
  Stream<QuerySnapshot> getReceiptsByCategory(String category) {
    try {
      return receiptsCollection
          .where('category', isEqualTo: category)
          .snapshots();
    } catch (e) {
      print('❌ Error filtering receipts by category: $e');
      return const Stream.empty();
    }
  }

  // ✅ Get Receipts by Date Range
  Stream<QuerySnapshot> getReceiptsByDateRange(
      DateTime startDate, DateTime endDate) {
    try {
      // Convert to ISO8601 format for Firestore
      String start = startDate.toUtc().toIso8601String();
      String end = endDate.toUtc().toIso8601String();

      return receiptsCollection
          .where('date', isGreaterThanOrEqualTo: start)
          .where('date', isLessThanOrEqualTo: end)
          .orderBy('date', descending: true)
          .snapshots();
    } catch (e) {
      print('❌ Error filtering receipts by date range: $e');
      return const Stream.empty();
    }
  }

  // ✅ Update a Receipt by ID
  Future<void> updateReceipt(
    String receiptId,
    Map<String, dynamic> receiptData,
  ) async {
    try {
      await receiptsCollection.doc(receiptId).update(receiptData);
      print('✅ Receipt updated successfully.');
    } catch (e) {
      print('❌ Error updating receipt: $e');
    }
  }

  // ✅ Check if Receipt Exists by ID
  Future<bool> receiptExists(String receiptId) async {
    try {
      final receiptDoc = await receiptsCollection.doc(receiptId).get();
      return receiptDoc.exists;
    } catch (e) {
      print('❌ Error checking if receipt exists: $e');
      return false;
    }
  }
}
