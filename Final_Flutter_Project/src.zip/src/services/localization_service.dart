import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:flutter/services.dart';

class LocalizationService extends ChangeNotifier {
  Locale _currentLocale = const Locale('en'); // Default locale
  Locale get currentLocale => _currentLocale;

  Map<String, dynamic> _localizedStrings = {};

  // ✅ Load saved locale from SharedPreferences on app start
  Future<void> loadLocale() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? locale = prefs.getString('locale') ?? 'en';
    _currentLocale = Locale(locale);
    await loadLocalizedStrings();
  }

  // ✅ Set and save new locale + reload strings
  Future<void> setLocale(Locale locale) async {
    if (_currentLocale == locale) return; // No need to update if same locale
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('locale', locale.languageCode);
    _currentLocale = locale;
    await loadLocalizedStrings();
    notifyListeners(); // Notify listeners when language changes
  }

  // ✅ Load localized JSON based on current locale
  Future<void> loadLocalizedStrings() async {
    try {
      String jsonString = await rootBundle
          .loadString('lib/localization/${_currentLocale.languageCode}.json');
      _localizedStrings = json.decode(jsonString);
    } catch (e) {
      debugPrint('Error loading localization file: $e');
      await _loadFallbackLocale();
    }
  }

  // ✅ Fallback to English in case of error
  Future<void> _loadFallbackLocale() async {
    try {
      String fallbackString =
          await rootBundle.loadString('lib/localization/en.json');
      _localizedStrings = json.decode(fallbackString);
      _currentLocale = const Locale('en');
    } catch (e) {
      debugPrint('Error loading fallback locale: $e');
      _localizedStrings = {}; // Empty map if fallback fails
    }
  }

  // ✅ Translate key with fallback
  String translate(String key) {
    return _localizedStrings[key] ?? key; // Return key if translation missing
  }

  // ✅ Supported Locales
  static const supportedLocales = [
    Locale('en', 'US'),
    Locale('es', 'ES'),
    Locale('fr', 'FR'),
    Locale('ta', 'IN'),
  ];
}

// ✅ Navigation Service to use navigatorKey globally
class NavigationService {
  static final GlobalKey<NavigatorState> navigatorKey =
      GlobalKey<NavigatorState>();
}
