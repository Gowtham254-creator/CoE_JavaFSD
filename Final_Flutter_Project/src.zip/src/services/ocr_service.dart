import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import 'package:http/http.dart';

class OcrService {
  final String _ocrApiUrl = 'https://api.ocr.space/parse/image';
  final String _apiKey = 'K86194158088957'; // Your OCR.Space API Key

  // ✅ Extract Text from Image (File Path)
  Future<String?> extractTextFromImage(String imagePath) async {
    try {
      var request = http.MultipartRequest(
        'POST',
        Uri.parse(_ocrApiUrl),
      );

      // ✅ Add API key and required fields
      request.fields['apikey'] = _apiKey;
      request.fields['language'] = 'eng';

      // ✅ Attach image file
      request.files.add(await http.MultipartFile.fromPath(
        'file',
        imagePath,
      ));

      final response =
          await request.send().timeout(const Duration(seconds: 30));
      final responseData = await response.stream.bytesToString();

      if (response.statusCode == 200) {
        return _parseOcrResponse(responseData);
      }
      return null;
    } catch (e) {
      print('❌ Error extracting text from image: $e');
      return null;
    }
  }

  // ✅ Extract Text from Base64 (for File Picker)
  Future<String?> extractTextFromBase64(Uint8List fileBytes) async {
    try {
      final base64Image = base64Encode(fileBytes);

      final response = await http.post(
        Uri.parse(_ocrApiUrl),
        body: {
          'apikey': _apiKey,
          'language': 'eng',
          'base64Image': 'data:image/jpeg;base64,$base64Image',
        },
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        return _parseOcrResponse(response.body);
      }
      return null;
    } catch (e) {
      print('❌ Error extracting text from base64: $e');
      return null;
    }
  }

  // ✅ Parse OCR API Response
  String? _parseOcrResponse(String responseData) {
    final data = json.decode(responseData);

    if (data['ParsedResults'] != null && data['ParsedResults'].isNotEmpty) {
      final parsedText = data['ParsedResults'][0]['ParsedText'];
      if (parsedText != null && parsedText.isNotEmpty) {
        print('✅ Extracted text: $parsedText');
        return parsedText;
      }
    }
    print('⚠️ No text found in the image.');
    return null;
  }
}
