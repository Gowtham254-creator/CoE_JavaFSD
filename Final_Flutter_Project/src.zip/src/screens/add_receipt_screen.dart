import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:provider/provider.dart';
import '../services/ocr_service.dart';
import '../services/firebase_service.dart';
import '../services/localization_service.dart';
import '../utils/constants.dart';

class AddReceiptScreen extends StatefulWidget {
  const AddReceiptScreen({super.key});

  @override
  _AddReceiptScreenState createState() => _AddReceiptScreenState();
}

class _AddReceiptScreenState extends State<AddReceiptScreen> {
  final FirebaseService _firebaseService = FirebaseService();
  final OcrService _ocrService = OcrService();

  final TextEditingController _storeController = TextEditingController();
  final TextEditingController _amountController = TextEditingController();
  String _extractedText = '';
  String _category = AppConstants.receiptCategories.first;
  File? _receiptImage;
  Uint8List? _webImage;
  bool _isLoading = false;

  // ✅ Pick Image from Camera, Gallery, or File Picker
  Future<void> _pickImage(ImageSource source) async {
    if (kIsWeb) {
      final result = await FilePicker.platform.pickFiles(type: FileType.image);
      if (result != null && result.files.single.bytes != null) {
        setState(() => _webImage = result.files.single.bytes);
        await _extractTextFromWeb(result.files.single.bytes!);
      }
    } else {
      final picker = ImagePicker();
      final XFile? image = await picker.pickImage(source: source);
      if (image != null) {
        setState(() => _receiptImage = File(image.path));
        await _extractTextFromImage(image.path);
      }
    }
  }

  // ✅ Extract Text from Mobile Image
  Future<void> _extractTextFromImage(String imagePath) async {
    setState(() => _isLoading = true);
    final text = await _ocrService.extractTextFromImage(imagePath);
    _processExtractedText(text);
  }

  // ✅ Extract Text from Web Image
  Future<void> _extractTextFromWeb(Uint8List bytes) async {
    setState(() => _isLoading = true);
    final text = await _ocrService.extractTextFromBase64(bytes);
    _processExtractedText(text);
  }

  // ✅ Process Extracted Text and Autofill Data
  void _processExtractedText(String? text) {
    if (text != null && text.isNotEmpty) {
      setState(() => _extractedText = text);
      _parseReceiptText(text);
    } else {
      _showSnackBar(
        Provider.of<LocalizationService>(context, listen: false)
                .translate('error_extract_text') ??
            'Error extracting text. Please try again.',
      );
    }
    setState(() => _isLoading = false);
  }

  // ✅ Parse Receipt Text and Autofill Fields
  void _parseReceiptText(String text) {
    final lines = text.split('\n');
    for (String line in lines) {
      if (line.toLowerCase().contains('total') ||
          line.toLowerCase().contains('amount')) {
        final amountMatch = RegExp(r'\d+(\.\d{1,2})?').firstMatch(line);
        if (amountMatch != null) {
          _amountController.text = amountMatch.group(0)!;
        }
      }
      if (line.toLowerCase().contains('store') ||
          line.toLowerCase().contains('shop')) {
        _storeController.text = line.replaceAll(RegExp(r'[^\w\s]'), '').trim();
      }
    }
  }

  // ✅ Save Receipt to Firebase
  Future<void> _saveReceipt() async {
    final localizationService =
        Provider.of<LocalizationService>(context, listen: false);

    if (_storeController.text.isEmpty || _amountController.text.isEmpty) {
      _showSnackBar(
        localizationService.translate('fill_all_fields') ??
            'Please fill all fields.',
      );
      return;
    }

    final receiptData = {
      'store': _storeController.text,
      'amount': _amountController.text,
      'category': _category,
      'date': DateTime.now().toIso8601String(),
      'extractedText': _extractedText,
      'imageUrl': _receiptImage != null
          ? _receiptImage!.path
          : (_webImage != null ? 'Web Image Uploaded' : ''),
    };

    try {
      await _firebaseService.addReceipt(receiptData);
      _showSnackBar(
        localizationService.translate('receipt_added_success') ??
            'Receipt added successfully!',
      );
      if (mounted) Navigator.pop(context, receiptData);
    } catch (e) {
      _showSnackBar(
        localizationService.translate('error_adding_receipt') ??
            'Error adding receipt. Please try again.',
      );
    }
  }

  // ✅ Show SnackBar for Feedback
  void _showSnackBar(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // ✅ Listen to LocalizationService to rebuild on language change
    return Consumer<LocalizationService>(
      builder: (context, localizationService, child) {
        return Scaffold(
          appBar: AppBar(
            title: Text(localizationService.translate('add_receipt') ??
                'Add Your Receipt'),
          ),
          body: Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/add_receipt_bg.jpg'),
                fit: BoxFit.cover,
              ),
            ),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  // ✅ Show Selected Image
                  if (_receiptImage != null)
                    Image.file(_receiptImage!, height: 200, fit: BoxFit.cover),
                  if (_webImage != null)
                    Image.memory(_webImage!, height: 200, fit: BoxFit.cover),
                  const SizedBox(height: 16),

                  // ✅ Buttons to Pick Image
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.camera_alt, size: 30),
                        onPressed: () => _pickImage(ImageSource.camera),
                        tooltip:
                            localizationService.translate('camera') ?? 'Camera',
                      ),
                      const SizedBox(width: 20),
                      IconButton(
                        icon: const Icon(Icons.photo, size: 30),
                        onPressed: () => _pickImage(ImageSource.gallery),
                        tooltip: localizationService.translate('gallery') ??
                            'Gallery',
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // ✅ Loading Indicator
                  if (_isLoading) const CircularProgressIndicator(),

                  // ✅ Receipt Details Form
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 8,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        TextField(
                          controller: _storeController,
                          decoration: InputDecoration(
                            labelText:
                                localizationService.translate('store_name') ??
                                    'Store Name',
                            border: const OutlineInputBorder(),
                          ),
                        ),
                        const SizedBox(height: 16),

                        TextField(
                          controller: _amountController,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            labelText:
                                localizationService.translate('amount') ??
                                    'Amount',
                            border: const OutlineInputBorder(),
                          ),
                        ),
                        const SizedBox(height: 16),

                        DropdownButtonFormField<String>(
                          value: _category,
                          onChanged: (String? newValue) {
                            setState(() => _category = newValue!);
                          },
                          items: AppConstants.receiptCategories
                              .map<DropdownMenuItem<String>>((String category) {
                            return DropdownMenuItem<String>(
                              value: category,
                              child: Text(
                                  localizationService.translate(category) ??
                                      category),
                            );
                          }).toList(),
                          decoration: InputDecoration(
                            labelText: localizationService
                                    .translate('select_category') ??
                                'Select Category',
                            border: const OutlineInputBorder(),
                          ),
                        ),
                        const SizedBox(height: 24),

                        // ✅ Add Receipt Button
                        ElevatedButton(
                          onPressed: _saveReceipt,
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(
                                vertical: 12, horizontal: 24),
                          ),
                          child: Text(
                            localizationService.translate('add_receipt') ??
                                'Add Receipt',
                            style: const TextStyle(fontSize: 18),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
