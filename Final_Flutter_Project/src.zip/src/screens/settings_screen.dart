import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:digital_organizer_app/services/localization_service.dart';
import 'package:digital_organizer_app/services/theme_service.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final themeService = Provider.of<ThemeService>(context);
    final localizationService = Provider.of<LocalizationService>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(localizationService.translate('settings')),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ✅ Theme Switch Toggle
            ListTile(
              title: Text(localizationService.translate('dark_mode')),
              trailing: Switch(
                value: themeService.isDarkMode,
                onChanged: (value) {
                  themeService.toggleTheme();
                },
              ),
            ),
            const SizedBox(height: 20),

            // ✅ Language Dropdown
            Text(localizationService.translate('language')),
            const SizedBox(height: 8),
            DropdownButton<Locale>(
              value: localizationService.currentLocale,
              onChanged: (Locale? newLocale) {
                if (newLocale != null) {
                  localizationService.setLocale(newLocale);
                }
              },
              items: const [
                DropdownMenuItem(
                  value: Locale('en'),
                  child: Text('English'),
                ),
                DropdownMenuItem(
                  value: Locale('es'),
                  child: Text('Español (Spanish)'),
                ),
                DropdownMenuItem(
                  value: Locale('fr'),
                  child: Text('Français (French)'),
                ),
                DropdownMenuItem(
                  value: Locale('ta'),
                  child: Text('தமிழ் (Tamil)'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
