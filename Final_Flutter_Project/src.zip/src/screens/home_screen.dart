// 📄 home_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/firebase_service.dart';
import '../services/localization_service.dart';
import '../widgets/receipt_card.dart';
import 'add_receipt_screen.dart';
import 'settings_screen.dart';
import 'receipt_details_screen.dart';
import 'login_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final FirebaseService _firebaseService = FirebaseService();

  // ✅ Confirm and Delete Receipt
  Future<bool?> _confirmAndDeleteReceipt(String receiptId) async {
    final localizationService = context.read<LocalizationService>();

    bool? confirmDelete = await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(localizationService.translate('delete_confirmation') ??
            'Delete Receipt?'),
        content: Text(localizationService.translate('delete_warning') ??
            'Are you sure you want to delete this receipt?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(localizationService.translate('cancel') ?? 'Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(
              localizationService.translate('delete') ?? 'Delete',
              style: const TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );

    if (confirmDelete == true) {
      await _deleteReceipt(receiptId);
      return true;
    }
    return false;
  }

  // ✅ Delete Receipt and Show Confirmation
  Future<void> _deleteReceipt(String receiptId) async {
    final localizationService = context.read<LocalizationService>();

    try {
      await _firebaseService.deleteReceipt(receiptId);
      _showSnackBar(localizationService.translate('delete_success') ??
          'Receipt deleted successfully!');
    } catch (e) {
      _showSnackBar(localizationService.translate('error_deleting_receipt') ??
          'Error deleting receipt. Please try again.');
    }
  }

  // ✅ Show SnackBar
  void _showSnackBar(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  // ✅ Navigate to Add Receipt Screen and Add New Receipt
  Future<void> _navigateToAddReceipt() async {
    final localizationService = context.read<LocalizationService>();

    final newReceipt = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const AddReceiptScreen()),
    );

    if (newReceipt != null && newReceipt is Map<String, dynamic>) {
      _showSnackBar(localizationService.translate('add_receipt_success') ??
          'Receipt added successfully!');
    }
  }

  // ✅ Navigate to Receipt Details Screen
  void _navigateToDetails(String receiptId) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ReceiptDetailsScreen(receiptId: receiptId),
      ),
    );
  }

  // ✅ Navigate to Settings Screen
  void _navigateToSettings() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const SettingsScreen()),
    );
  }

  // 🔐 ✅ Logout and Navigate to Login Screen
  void _logout(BuildContext context) {
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const LoginScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final localizationService = Provider.of<LocalizationService>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          localizationService.translate('receipts_title') ?? 'Your Receipts',
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: _navigateToSettings,
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => _logout(context),
          ),
        ],
      ),
      body: Stack(
        children: [
          // ✅ Background Image
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/home_bg.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          // ✅ StreamBuilder to Load Receipts
          StreamBuilder<QuerySnapshot>(
            stream: _firebaseService.getReceipts(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return _buildErrorMessage(
                    localizationService.translate('error_loading_receipts') ??
                        'Error loading receipts. Please try again later.');
              }
              if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                return _buildEmptyMessage(
                    localizationService.translate('no_receipts') ??
                        'No receipts found. Add a new receipt to get started!');
              }

              final receipts = snapshot.data!.docs;

              return ListView.builder(
                itemCount: receipts.length,
                itemBuilder: (context, index) {
                  var receipt = receipts[index];
                  var data = receipt.data() as Map<String, dynamic>;

                  return Dismissible(
                    key: Key(receipt.id),
                    direction: DismissDirection.endToStart,
                    confirmDismiss: (direction) =>
                        _confirmAndDeleteReceipt(receipt.id),
                    background: _buildDeleteBackground(),
                    child: GestureDetector(
                      onTap: () => _navigateToDetails(receipt.id),
                      child: ReceiptCard(
                        store: data['store'] ?? 'Unknown Store',
                        totalAmount: _formatAmount(data['amount']),
                        category: data['category'] ?? 'Uncategorized',
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToAddReceipt,
        child: const Icon(Icons.add),
      ),
    );
  }

  // ✅ Build Empty State Message
  Widget _buildEmptyMessage(String message) {
    return Center(
      child: Text(
        message,
        style: const TextStyle(color: Colors.white),
      ),
    );
  }

  // ✅ Build Error State Message
  Widget _buildErrorMessage(String message) {
    return Center(
      child: Text(
        message,
        style: const TextStyle(color: Colors.white),
      ),
    );
  }

  // ✅ Build Background for Swipe Delete
  Widget _buildDeleteBackground() {
    return Container(
      color: Colors.red,
      alignment: Alignment.centerRight,
      padding: const EdgeInsets.only(right: 20),
      child: const Icon(Icons.delete, color: Colors.white),
    );
  }

  // ✅ Format Amount Helper
  String _formatAmount(dynamic amount) {
    if (amount == null) return '\$0.00';
    if (amount is double) {
      return '\$${amount.toStringAsFixed(2)}';
    } else if (amount is String) {
      double? parsedAmount = double.tryParse(amount);
      return parsedAmount != null
          ? '\$${parsedAmount.toStringAsFixed(2)}'
          : '\$0.00';
    }
    return '\$0.00';
  }
}
