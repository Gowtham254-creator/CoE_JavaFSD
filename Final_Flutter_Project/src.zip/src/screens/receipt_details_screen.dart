import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/firebase_service.dart';

class ReceiptDetailsScreen extends StatelessWidget {
  final String receiptId;

  const ReceiptDetailsScreen({Key? key, required this.receiptId})
      : super(key: key);

  // ✅ Delete receipt and show confirmation
  Future<void> _deleteReceipt(BuildContext context) async {
    bool? confirmDelete = await _showDeleteConfirmation(context);
    if (confirmDelete == true) {
      await FirebaseService().deleteReceipt(receiptId);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✅ Receipt deleted successfully.'),
        ),
      );
      Navigator.pop(context); // Go back after deleting
    }
  }

  // 🛑 Show delete confirmation dialog
  Future<bool?> _showDeleteConfirmation(BuildContext context) {
    return showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Receipt'),
        content: const Text('Are you sure you want to delete this receipt?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Receipt Details'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete, color: Colors.red),
            onPressed: () => _deleteReceipt(context), // 🔥 Trigger delete
          ),
        ],
      ),
      body: FutureBuilder<DocumentSnapshot?>(
        future: FirebaseService().getReceiptById(receiptId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || !snapshot.data!.exists) {
            return const Center(child: Text('❌ Receipt not found.'));
          }

          final data = snapshot.data!.data() as Map<String, dynamic>;

          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: ListView(
              children: [
                _buildDetail('🏬 Store Name', data['store'] ?? 'Unknown'),
                _buildDetail('📦 Category', data['category'] ?? 'Unknown'),
                _buildDetail(
                    '💸 Total Amount', '\$${data['amount'] ?? '0.00'}'),
                _buildDetail('📅 Date', data['date'] ?? 'N/A'),
                const SizedBox(height: 20),
                const Text(
                  '📝 Extracted Text:',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 5),
                Text(
                  data['extractedText'] ?? 'No extracted text available.',
                  style: const TextStyle(fontSize: 14),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Back to Receipts'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // 📝 Build receipt detail row
  Widget _buildDetail(String title, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          Flexible(
            child: Text(
              value,
              style: const TextStyle(fontSize: 16),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}
