// receipt.dart
class Receipt {
  final String id;
  final String storeName;
  final String amount;
  final String category;
  final String date;
  final String imageUrl;

  Receipt({
    required this.id,
    required this.storeName,
    required this.amount,
    required this.category,
    required this.date,
    required this.imageUrl,
  });

  factory Receipt.fromMap(Map<String, dynamic> data, String documentId) {
    return Receipt(
      id: documentId,
      storeName: data['storeName'] ?? '',
      amount: data['amount'] ?? '',
      category: data['category'] ?? '',
      date: data['date'] ?? '',
      imageUrl: data['imageUrl'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'storeName': storeName,
      'amount': amount,
      'category': category,
      'date': date,
      'imageUrl': imageUrl,
    };
  }
}
