import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  imports: [FormsModule, CommonModule], // ✅ Remove MenubarComponent & FooterComponent
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(private router: Router) {} // ✅ Inject Router

  // ✅ Login Logic with Navigation
  login() {
    if (this.username === 'Gowtham' && this.password === 'password') {
      localStorage.setItem('isLoggedIn', 'true'); // ✅ Save login state
      localStorage.setItem('username', this.username);

      // ✅ Redirect to home after login
      this.router.navigate(['/']);
    } else {
      this.errorMessage = 'Invalid username or password';
    }
  }
}
