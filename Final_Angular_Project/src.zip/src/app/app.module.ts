import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';  // Import AppRoutingModule for routing
import { FormsModule } from '@angular/forms';  // Import FormsModule to use ngModel

// Import Components
import { MenubarComponent } from './common/menu-bar/menu-bar.component';
import { FooterComponent } from './common/footer/footer.component';
import { LoginComponent } from './common/login/login.component';
import { AppComponent } from './app.component';

// Import Pipes
import { JobFilterPipe } from './pipes/job-filter.pipe';  // Import JobFilterPipe correctly

// Import AuthService
import { AuthService } from './services/auth.service';
import { JobApplicationComponent } from './pages/job-application/job-application.component';  // Correct AuthService import path

@NgModule({
  declarations: [
    AppComponent,        // Declare root AppComponent
    MenubarComponent,    // Declare MenubarComponent
    FooterComponent,     // Declare FooterComponent
    LoginComponent,      // Declare LoginComponent
    JobFilterPipe, JobApplicationComponent        // Declare JobFilterPipe (fixed duplicate comment)
  ],
  imports: [
    BrowserModule,       // Import BrowserModule to run in the browser
    FormsModule,         // Import FormsModule for two-way binding (ngModel)
    AppRoutingModule     // Import AppRoutingModule for routing
  ],
  providers: [
    AuthService          // Provide AuthService correctly
  ],
  bootstrap: [AppComponent]  // Bootstrap AppComponent as the root
})
export class AppModule { }
