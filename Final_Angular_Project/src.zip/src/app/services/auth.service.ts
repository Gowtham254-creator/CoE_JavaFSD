// src/app/services/auth.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private isLoggedInSubject = new BehaviorSubject<boolean>(
    this.checkLoginStatus()
  );
  isLoggedIn$ = this.isLoggedInSubject.asObservable();

  constructor() {}

  // ✅ Login method to authenticate
  logIn(username: string, password: string): boolean {
    if (username === 'admin' && password === 'password') {
      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem('username', username);
      this.isLoggedInSubject.next(true);
      return true;
    }
    return false;
  }

  // ✅ Logout method to clear storage
  logOut(): void {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('username');
    this.isLoggedInSubject.next(false);
  }

  // ✅ Check login status for AuthGuard
  isAuthenticated(): boolean {
    return localStorage.getItem('isLoggedIn') === 'true';
  }

  // ✅ Check login status on page reload
  private checkLoginStatus(): boolean {
    return localStorage.getItem('isLoggedIn') === 'true';
  }
}
