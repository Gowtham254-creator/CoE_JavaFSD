import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-job-application',
  templateUrl: './job-application.component.html',
  styleUrls: ['./job-application.component.css'],
  standalone: true,
  imports: [FormsModule], // ✅ Import FormsModule here
})
export class JobApplicationComponent implements OnInit {
  jobId!: number;
  applicant = {
    name: '',
    email: '',
    resume: null,
  };

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    // Get the job ID from the URL
    this.jobId = Number(this.route.snapshot.paramMap.get('id'));
  }

  onFileSelected(event: any): void {
    this.applicant.resume = event.target.files[0];
  }

  submitApplication(): void {
    console.log('Application submitted for job ID:', this.jobId);
    console.log('Applicant Details:', this.applicant);
    // Add logic to submit data to API
  }
}
