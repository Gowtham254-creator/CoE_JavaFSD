import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MenubarComponent } from './common/menu-bar/menu-bar.component';
import { FooterComponent } from './common/footer/footer.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterModule, MenubarComponent, FooterComponent], // Remove NgIf if not used
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'job-portal';
}
