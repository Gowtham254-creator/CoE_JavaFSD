import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { EnquiriesComponent } from './pages/enquiries/enquiries.component';
import { JobListComponent } from './pages/job-list/job-list.component';
import { JobPostComponent } from './pages/job-post/job-post.component';
import { LoginComponent } from './common/login/login.component';
import { JobApplicationComponent } from './pages/job-application/job-application.component'; // Import Job Application Component

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' }, // Redirect to home on load
  { path: 'home', component: HomeComponent }, // Route for Home
  { path: 'enquiries', component: EnquiriesComponent }, // Route for Enquiries
  { path: 'job-list', component: JobListComponent }, // Route for Job List
  { path: 'job-post', component: JobPostComponent }, // Route for Job Post
  { path: 'login', component: LoginComponent }, // Route for Login
  { path: 'apply/:id', component: JobApplicationComponent }, // Route for Job Application Form
  { path: '**', redirectTo: '/home' }, // Redirect any unknown path to Home
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
