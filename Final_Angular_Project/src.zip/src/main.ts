import { importProvidersFrom } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app/app.component';
import { HomeComponent } from './app/pages/home/home.component';
import { JobListComponent } from './app/pages/job-list/job-list.component';
import { JobPostComponent } from './app/pages/job-post/job-post.component';
import { EnquiriesComponent } from './app/pages/enquiries/enquiries.component';
import { LoginComponent } from './app/common/login/login.component';
import { JobApplicationComponent } from './app/pages/job-application/job-application.component'; // ✅ Import Job Application
import { AuthService } from './app/services/auth.service';
import { AuthGuard } from './app/services/auth.guard';

// ✅ Updated routes configuration with Job Application
const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' }, // ✅ Redirect to Home by default
  { path: 'home', component: HomeComponent }, // ✅ No AuthGuard for Home
  { path: 'login', component: LoginComponent }, // Login can be accessed without AuthGuard
  { path: 'job-list', component: JobListComponent, canActivate: [AuthGuard] },
  { path: 'job-post', component: JobPostComponent, canActivate: [AuthGuard] },
  { path: 'enquiries', component: EnquiriesComponent, canActivate: [AuthGuard] },
  { path: 'apply/:id', component: JobApplicationComponent, canActivate: [AuthGuard] }, // ✅ Added route for Job Application
  { path: '**', redirectTo: 'home' }, // ✅ Catch invalid routes
];

// ✅ Bootstrap application with corrected providers
bootstrapApplication(AppComponent, {
  providers: [
    provideRouter(routes),
    importProvidersFrom(FormsModule),
    AuthService,
    AuthGuard,
  ],
}).catch((err) => console.error(err));
